// ============================================================
// FIREBASE CONFIG
// ============================================================
// 1. Go to https://console.firebase.google.com
// 2. Create a project (free) called "Vimal Farms" (or anything)
// 3. Click the "</>" web icon to register a web app
// 4. Copy the config object it gives you and paste the values below
// 5. In the Firebase Console:
//      - Build > Authentication > Get Started > enable "Email/Password"
//      - Build > Firestore Database > Create database > start in
//        "Production mode" (or test mode while developing)
// ============================================================

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();
